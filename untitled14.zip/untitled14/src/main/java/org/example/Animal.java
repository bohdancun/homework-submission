package org.example;

public abstract class Animal {
    protected String name;
    protected int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public abstract String makeSound();
    public abstract String move();
    public abstract String naturalHabitat();

    public void displayInformation() {
        System.out.println("Animal: " + name + ", Age: " + age);
    }
}
