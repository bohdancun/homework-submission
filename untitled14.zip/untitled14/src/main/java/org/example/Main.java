package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Mammal lion = new Mammal("Leo the Lion", 5, "golden");
        Bird eagle = new Bird("Eddie the Eagle", 3, 2.1);
        Reptile snake = new Reptile("Sly the Snake", 2, true);

        Animal[] animals = {lion, eagle, snake};

        for (Animal animal : animals) {
            animal.displayInformation();
            System.out.println("Sound: " + animal.makeSound());
            System.out.println("Movement: " + animal.move());
            System.out.println("Habitat: " + animal.naturalHabitat());

            if (animal instanceof Mammal) {
                ((Mammal) animal).groom();
            } else if (animal instanceof Bird) {
                ((Bird) animal).fly();
            } else if (animal instanceof Reptile) {
                ((Reptile) animal).shedSkin();
            }

            System.out.println("-----------------------");
        }
    }
}
