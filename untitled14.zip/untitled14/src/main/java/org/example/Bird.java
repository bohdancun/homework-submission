package org.example;

public class Bird extends Animal {
    private double wingSpan;

    public Bird(String name, int age, double wingSpan) {
        super(name, age);
        this.wingSpan = wingSpan;
    }

    public double getWingSpan() {
        return wingSpan;
    }

    public void fly() {
        System.out.println(name + " is flying with a wingspan of " + wingSpan + " meters.");
    }

    @Override
    public String makeSound() {
        return "Bird chirps or sings";
    }

    @Override
    public String move() {
        return "Bird flies";
    }

    @Override
    public String naturalHabitat() {
        return "Trees, mountains, or wetlands";
    }
}
