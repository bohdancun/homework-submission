package org.example;

public class Mammal extends Animal {
    private String furColor;

    public Mammal(String name, int age, String furColor) {
        super(name, age);
        this.furColor = furColor;
    }

    public String getFurColor() {
        return furColor;
    }

    public void groom() {
        System.out.println(name + " is grooming its " + furColor + " fur.");
    }

    @Override
    public String makeSound() {
        return "Mammal sound";
    }

    @Override
    public String move() {
        return "Mammal walks or runs";
    }

    @Override
    public String naturalHabitat() {
        return "Forests, grasslands, or savannas";
    }
}
